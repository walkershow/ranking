-- @Author: coldplay
-- @Date:   2015-11-21 16:18:47
-- @Last Modified by:   coldplay
-- @Last Modified time: 2015-12-15 17:49:09


-- local redis = require "resty.redis"
local str = require "resty.string"
-- local config = require "config"
local red_pool = require "redis_pool"

function beating(uid)
	-- if uid==nil then
	-- 	ngx.exit(ngx.HTTP_BAD_REQUEST)
	-- end
	local bupdate = false
	local diff_time = 0
	-- os.time 和 os.date 会涉及系统调用，尽量使用 ngx_lua 提供的接口获取 Nginx 内部的缓存时间吧。系统调用的开销是很可观的。
	local req_time = ngx.time()

	local ret,red = red_pool.get_connect()
	if ret == false then
		ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
	end
	local key = string.format("login:%s:last_logintime",uid)
	local res, errget= red:get(key)
	if not res then
		red_pool.close()
		-- red:set_keepalive(10000, 100)
	   ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
	end

	if res == ngx.null then
		bupdate = true
	else
		diff_time = os.difftime (req_time, res)
		-- if diff_time >= 60 then
			bupdate = true
		-- end
	end
	if bupdate==true then
		local alive_time = 300
		local now_min = tonumber(os.date("%M", ngx.time()))
		local now_hor = tonumber(os.date("%H", ngx.time()))
		-- local now_time = os.date("%H:%M", os.time())
		local online_key = "online:"..now_hor..":".. now_min


		local linetime_key = string.format("level:%s:linetime",uid)
		local sql = "update chinau_member set line_time = line_time+1 where id=".. uid
		-- local nlinetime
		red:init_pipeline()
	    red:sadd(online_key, uid)
	    red:expire(online_key, 300)
	    red:setex(key, alive_time, req_time)
	    -- red:get(linetime_key)
	    red:incrby(linetime_key, 1)

	    -- red:zrevrangebyscore("linetime", nlinetime, 0, "limit", 0 ,1)
	    red:lpush("chinau_6a",sql)
	    local results, err = red:commit_pipeline()
	    -- local cjson = require "cjson"
	    -- ngx.say(cjson.encode(results))
	    if not results then
	        ngx.log(ngx.ERR,"failed to commit the pipelined requests: ", err)
            red_pool.close()
            ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
	    end

	    for i, res in ipairs(results) do
            	if not res then
               		ngx.log(ngx.ERR,"failed to run command ".. i.. ": ".. (res or "nil"))
            		red_pool.close()
            		ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)

            	end
            	-- if i == 4 then
            	-- 	nlinetime = res
            	-- end

        end
        --客户端每次启动下载等级配置表，当触发升级条件后调用服务器level接口
  --       local level = red:zrevrangebyscore("linetime", nlinetime, 0, "limit", 0 ,1)
		-- local cjson = require "cjson"
		-- ngx.say(cjson.encode(level))
		red_pool.close()
	end
end


local args = ngx.req.get_uri_args(6)
local auid = ngx.quote_sql_str(args.userid)
beating(auid)
